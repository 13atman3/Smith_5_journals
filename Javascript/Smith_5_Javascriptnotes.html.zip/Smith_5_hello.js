alert('Howdy Brah!') 
window.alert('This is a window')
window.confirm('Shall we continue?')

var x = 42;
document.write(x);
